from selenium import webdriver
import time
options = webdriver.ChromeOptions()
#options=  webdriver.FirefoxOptions()
options.add_argument('--ignore-certificate-errors')
options.add_argument("--test-type")
options.binary_location = "/usr/bin/chromedriver"
driver = webdriver.Chrome(chrome_options=options)
#driver = webdriver.firefox(firefox_options=options)

#driver= webdriver.chrome(executable_path="/home/qbuser/PycharmProjects/PythonSelenium/Drivers/chromedriver")
driver.get('https://python.org')
html = driver.page_source
print(driver.title)
driver.quit();
# Firefox
#driver = webdriver.Firefox()

# Google Chrome
#driver = webdriver.Chrome()

# iPhone
#driver = webdriver.Remote(browser_name="iphone", command_executor='http://172.24.101.36:3001/hub')

# Android
#driver = webdriver.Remote(browser_name="android", command_executor='http://127.0.0.1:8080/hub')