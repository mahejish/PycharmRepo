
import xlwt as xlwt
import xlrd as xlrd

class DataProvider:
    def __init__(self):
        self.dataDict={}

    def getDataDict(self,filepath,sheetNo,epicNo):
        book = xlrd.open_workbook(filepath)
        # print(book.nsheets)
        # print(book.sheet_names())
        sheet = book.sheet_by_name(book.sheet_names()[sheetNo])
        row_num = epicNo-1
        num_col = sheet.ncols
        list_key = []
        list_val = []
        for j in range(num_col):
            list_key.append(sheet.cell_value(0, j))

        for j in range(num_col):
            list_val.append(sheet.cell_value(row_num, j))

        dataDict=dict(zip(list_key, list_val))
        return dataDict




book=xlrd.open_workbook('/home/qbuser/Music/myworkbook.xls')
# print(book.nsheets)
# print (book.sheet_names())
sheet=book.sheet_by_name(book.sheet_names()[0])
# sheet=book.sheet_by_index(0)
# row=2
# col=2
num_rows=sheet.nrows
num_col=sheet.ncols
list_key = []
list_val = []
mydic = {}

for j in range(num_col):
    list_key.append(sheet.cell_value(0, j))

for j in range(num_col):
    list_val.append(sheet.cell_value(1, j))

mydic=dict(zip(list_key, list_val))

# print(mydic['intentToUse'])
