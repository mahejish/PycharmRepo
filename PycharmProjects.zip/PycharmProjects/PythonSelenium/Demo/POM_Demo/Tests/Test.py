from selenium import webdriver
# from numpy import *
import unittest
import HtmlTestRunner

from Demo.POM_Demo.Pages.Page1 import SignUpPage
class LoginTest(unittest.TestCase):


    @classmethod
    def setUp(self):
        self.driver=webdriver.Chrome('/home/qbuser/PycharmProjects/PythonSelenium/Demo/POM_Demo/Drivers/chromedriver')
        #self.driver = webdriver.Firefox()
        self.driver.get("https://www.autopilothq.com/")
        self.driver.maximize_window()
        self.driver.implicitly_wait(30)
        #print(self.driver.title)


    def testPythonScript1(self):
        driver=self.driver
        signUp=SignUpPage(driver)
        signUp.signUp_validation("")

    # def testPythonScript2(self):
    #     driver=self.driver
    #     signUp=SignUpPage(driver)w+
    #     signUp.signUp_validation()

    @classmethod
    def tearDown(self):
        driver = self.driver
        driver.quit();


if __name__ == "__main__":
    unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='/home/qbuser/PycharmProjects/PythonSelenium/Demo/POM_Demo/Reports'))



