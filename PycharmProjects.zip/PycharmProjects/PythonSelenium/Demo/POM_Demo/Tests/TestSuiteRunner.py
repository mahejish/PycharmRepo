__author__ = 'Jishnu'

import unittest
import os
from Demo.POM_Demo.Tests.Test import LoginTest
from Demo.POM_Demo.Tests.Test2 import LoginTest2

import HTMLTestRunner

direct = os.getcwd()


class MyTestSuite(unittest.TestCase):

    def test_Issue(self):
        smoke_test = unittest.TestSuite()
        smoke_test.addTests([
            unittest.defaultTestLoader.loadTestsFromTestCase(LoginTest.testPythonScript1()),
            unittest.defaultTestLoader.loadTestsFromTestCase(LoginTest2.testPythonScript2()),
        ])

        outfile = open(direct + "\SmokeTest.html", "w")

        runner1 = HTMLTestRunner.HTMLTestRunner(
            stream=outfile,
            title='Test Report',
            description='Smoke Tests'
        )

        runner1.run(smoke_test)


if __name__ == '__main__':
    unittest.main()