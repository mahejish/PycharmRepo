

# import  os
# print(os.path.abspath("."))

# x='jishnu'
# print(x[-(len(x))])
# print(x[::-1])
# from builtins import print
# from lib2to3.pgen2 import driver
#
# nums=[]
# for i in range(10):
#     nums.append(i)
# print(nums.index(6)) #will give the index number of the value in the list
# print(nums.count(2)) #will give number of occurance of a number
# print(nums)
# nums[9]=10
# print(nums)
# nums.insert(4,99)
# print(nums)
# nums.remove(99)
# print(nums)
# nums.pop(9)
# print(nums)
# del nums[5:]
# print(nums)
# nums.extend([5,6,7,8,9])
# print(nums)
# print(max(nums))
# print(min(nums))
# nums.sort(reverse=True)
# print(nums)
# nums.sort()
# print(nums)


# l=['a',3,3.4]
# t=('b','l',3,4,1.5)
# s={10,4,'d','fs',4}
# print(l)
# print(t)
# print(s)

# a=3
# b=10
# c=a<b
# print(c)
# print(type(c))

# x=True
# y=False
# print(type(x))
# print(type(y))
# print(x)
# print(y)
# print(int(x))
# print(int(y))
# print(float(x))
# print(float(y))
# print(bool(x))
# print(bool(y))
# print(complex(x))
# print(complex(y))

# print(range(10))
# print(list(range(10)))
# print(list(range(1,10,2)))
# print(list(range(0,10,2)))

# assert "Python" is 'Python'
# print('Pass')
# assert "Python" in 'Python Language'
# print('Pass')

# tup1=((1,2),("a","b"))
# enum=enumerate(tup1)
# for i, row in enum:
#     # print(row)
#     for j, col in enumerate(row):
#         print(col)

# all_options = [11,3,5,7,44,36]
# for option in all_options:
#     print("Value is: %s" % option)

# from selenium import webdriver
# from selenium.webdriver import ActionChains
# driver=webdriver.Firefox()
# element = driver.find_element_by_name("source")
# target = driver.find_element_by_name("target")
#
#
# action_chains = ActionChains(driver)
# action_chains.drag_and_drop(element, target).perform()
# action_chains.move_to_element(element).perform()

# import os
# import unittest
# from appium import webdriver
#
# desired_caps = {}
# desired_caps['platformName'] = 'Android'
# desired_caps['platformVersion'] = '6.0.1'
# desired_caps['deviceName'] = 'Galaxy Tab S2'
# desired_caps['udid'] = '3300e8c2774aa281'
# desired_caps['browserName'] = 'chrome'
#
#
# driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)
#
# print("testing")
#
# driver.quit()
# from colorama import Fore, Back, Style
# x="Jishnu"
# print(Back.MAGENTA + x)
# print(Back.GREEN + 'and with a green background')
# print(Style.DIM + 'and in dim text')
# print(Style.RESET_ALL)
# print('back to normal now',10,1000)

# from selenium import webdriver
# driver=webdriver.Chrome('/home/qbuser/PycharmProjects/PythonSelenium/Demo/POM_Demo/Drivers/chromedriver')
# driver.get("https://www.autopilothq.com/")
# driver.maximize_window()
# driver.implicitly_wait(30)
#
#
# Dict = {}
# driver.find_element_by_xpath("(//span[text()='Free Trial'])").click()
# Dict["id"] = driver.find_element_by_xpath("(//input[@name='firstname'])").get_attribute("id")
# Dict["class"] = driver.find_element_by_xpath("(//input[@name='firstname'])").get_attribute("class")
# Dict["name"] = driver.find_element_by_xpath("(//input[@name='firstname'])").get_attribute("name")
# Dict["Text"] = driver.find_element_by_xpath("(//input[@name='firstname'])").get_attribute("text")
# Dict["LinkText"] = driver.find_element_by_xpath("(//input[@name='firstname'])").get_attribute("LinkText")
# Dict["Css_Selector"] = driver.find_element_by_xpath("(//input[@name='firstname'])").get_attribute("CssSelector")
# Dict["Xpath_relative"] = driver.find_element_by_xpath("(//input[@name='firstname'])").get_attribute("text")
# Dict["Unique_property"] = driver.find_element_by_xpath("(//input[@name='firstname'])").get_attribute("Unique_property")
# print(driver.find_element_by_xpath("(//input[@name='firstname'])").get_attribute('outerHTML'))
#
#
# print(Dict)
# driver.close()
import io
import json


# data = {}
# data['Parameter'] = []
# data['Parameter'].append({
# "Text":Dict["Text"],
# "Id":Dict["id"],
# "Class":Dict["class"],
# "Xpath_relative":Dict["Xpath_relative"],
# "Css_Selector":"value",
# "Name":Dict["name"],
# "LinkText":Dict["LinkText"],
# "Unique_property":Dict["Unique_property"]
# })
#
# data['Parameter'].append({
#     'name': 'Tim',
#     'website': 'apple.com',
#     'from': 'Alabama'
# })
#
# with open('/home/qbuser/Documents/data2.json', 'w') as outfile:
#     json.dump(data, outfile)




# {
#   "@name": "test",
#   "test": {
#      "@name": "nameOfTest",
#      "Object": {
#         "@name": "Login_Button",
#         "Parameter": [
#            {
# "Text":"value",
# "Id":"value",
# "Class":"value",
# "Xpath_relative":"value",
# "Css_Selector":"value",
# "Name":"value",
# "LinkText":"value",
# "Unique_property":"Value"}]
#      }
#   }
# }









# import json
#
# data1 = {}
# data2= {}
# data3 = {}
# data1['people1'] = []
# data2['people2'] = []
# data3['people3'] = []
# data1['people1'].append({
#     'name': 'Scott',
#     'website': 'stackabuse.com',
#     'from': 'Nebraska'
# })
# data2['people2'].append({
#     'name': 'Larry',
#     'website': 'google.com',
#     'from': 'Michigan'
# })
# data3['people3'].append({
#     'name': 'Tim',
#     'website': 'apple.com',
#     'from': 'Alabama'
# })
#
# with open('/home/qbuser/Documents/x1.json', 'w') as outfile:
#     json.dump(data3, outfile)
#
#
# import json
# with open('/home/qbuser/Documents/x1.json','r') as f:
#   data = json.load(f)
#   print(data['iFrame'])

# print((((((data['test'])["Object"])["Parameter"]))[0])["Id"])
# print((((((data['test'])["Object"])["Parameter"]))[0])["Name"])
# print((((((data['test'])["Object"])["Parameter"]))[0])["Class"])
# print((((((data['test'])["Object"])["Parameter"]))[0])["Xpath_relative"])
# print((((((data['test'])["Object"])["Parameter"]))[0])["Css_Selector"])
import os

# if os.path.isfile('/home/qbuser/Documents/demo.json') and os.access('/home/qbuser/Documents/demo.json',os.R_OK):
#     # checks if file exists
#     print("File exists and is readable")
# else:
#     print("Either file is not existing or is not readable, creating a new file...")
#     with io.open(os.path.join('/home/qbuser/Documents', 'demo.json'), 'w') as db_file:
#         db_file.write(json.dumps({}))

str="Jishnu.Mahesh"
print(str.split("."))