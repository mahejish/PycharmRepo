from selenium import webdriver
# from numpy import *
import unittest
import HtmlTestRunner
from appium import webdriver
from Demo.POM_Demo.Pages.Page1 import SignUpPage


class LoginTest(unittest.TestCase):

    def setUp(self):
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '6.0.1'
        desired_caps['deviceName'] = 'Galaxy Tab S2'
        desired_caps['udid'] = '3300e8c2774aa281'
        desired_caps['browserName'] = 'chrome'

        self.driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)

        self.driver.get("https://www.autopilothq.com/")

    def testPythonScript(self):
        driver=self.driver
        signUp=SignUpPage(driver)
        signUp.signUp_validation("mob")

    # def testPythonScript2(self):
    #     driver=self.driver
    #     signUp=SignUpPage(driver)
    #     signUp.signUp_validation()


    def tearDown(self):
        driver = self.driver
        driver.quit();


if __name__ == "__main__":
    unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='/home/qbuser/PycharmProjects/PythonSelenium/Demo/POM_Demo/Reports'))



