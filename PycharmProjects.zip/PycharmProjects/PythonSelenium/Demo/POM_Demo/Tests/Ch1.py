import unittest
from selenium import webdriver


class TestParallel(unittest.TestCase):
    def setUp(self):
        self.driver=webdriver.Remote(
            cammand_executor="http://localhost:4444/wd/hub",
            desired_capabilities={
                "browserName":"chrome",
            })
        self.driver.implicitly_wait(30)


    def test_chrome(self):
        driver_chrome = self.driver
        driver_chrome.get('http://www.google.com')



    def tearDown(self):
        self.driver.close()

if __name__ == "__main__":
    unittest.main()