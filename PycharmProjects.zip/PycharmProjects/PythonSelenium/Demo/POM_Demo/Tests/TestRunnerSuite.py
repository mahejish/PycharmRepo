import HtmlTestRunner
from HtmlTestRunner import HTMLTestRunner
from selenium import webdriver
# from numpy import *
import unittest
import HtmlTestRunner
import os
from Demo.POM_Demo.Tests.Test import LoginTest
from Demo.POM_Demo.Tests.Test2 import LoginTest
direct = os.getcwd()


class MyTestSuite(unittest.TestCase):

    def test_Issue(self):
        smoke_test = unittest.TestSuite()
        smoke_test.addTests([
            unittest.defaultTestLoader.loadTestsFromTestCase(LoginTest.testPythonScript1()),
            unittest.defaultTestLoader.loadTestsFromTestCase(LoginTest.testPythonScript1()),
        ])

        outfile = open(direct + "\SmokeTest.html", "w")

        runner1 = HTMLTestRunner.HTMLTestRunner(
            stream=outfile,
            title='Test Report',
            description='Smoke Tests'
        )

        runner1.run(smoke_test)


# if __name__ == "__main__":
#     unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='/home/qbuser/PycharmProjects/PythonSelenium/Demo/POM_Demo/Reports'))



