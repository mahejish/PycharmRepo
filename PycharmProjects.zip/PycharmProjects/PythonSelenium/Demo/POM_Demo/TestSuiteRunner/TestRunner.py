from selenium import webdriver
import testtools
import unittest
import HtmlTestRunner

from Demo.POM_Demo.Tests import *
class TestSuit(unittest.TestCase):
    x=3


suite = unittest.TestLoader().loadTestsFromTestCase(TestSuit)
concurrent_suite = testtools.ConcurrentStreamTestSuite(lambda: ((case, None) for case in suite))
concurrent_suite.run(testtools.StreamResult())

if __name__ == "__main__":
    unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='/home/qbuser/PycharmProjects/PythonSelenium/Demo/POM_Demo/Reports'))


# https://jishnumahesh.atlassian.net/jira/software/projects/SRP/boards/1/backlog
