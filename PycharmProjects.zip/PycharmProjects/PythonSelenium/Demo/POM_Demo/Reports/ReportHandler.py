import base64
from datetime import datetime
from colorama import Fore, Back, Style
class Report:
    def __init__(self,driver):
        self.driver=driver

    def testCaseStatus(self,str):
        picName=datetime.now().strftime("%d-%b-%Y (%H:%M:%S.%f)")
        self.driver.save_screenshot("/home/qbuser/PycharmProjects/PythonSelenium/Demo/POM_Demo/Screenshots/"+picName+".png")
        data_uri = base64.b64encode(open('/home/qbuser/PycharmProjects/PythonSelenium/Demo/POM_Demo/Screenshots/'+picName+'.png', 'rb').read()).decode(
            'utf-8')
        img_tag = '<img src="data:image/png;base64,{0}">'.format(data_uri)
        textTag='<h1 style="font-size:75px;background-color:rgb(0, 255, 128);">'+str+'</h1>'
        print(img_tag+'\n')
        print(textTag)


