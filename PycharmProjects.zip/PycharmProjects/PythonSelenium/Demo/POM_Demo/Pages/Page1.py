import json
import os
from Demo.POM_Demo.Locators.SignUpLocators import SignUpLocator
from Demo.POM_Demo.Reports.ReportHandler import Report
from Demo.POM_Demo.TestDataHandler.ExeldataHandler import DataProvider
from Demo.POM_Demo.BaseFunctions.BaseFunctions import BaseFunctions
from Demo.POM_Demo.BaseFunctions.BaseFunctions import data
import time
class SignUpPage():
    def __init__(self,driver):
        self.driver=driver
        self.testData=DataProvider().getDataDict("/home/qbuser/PycharmProjects/PythonSelenium/Demo/POM_Demo/TestDataHandler/myworkbook.xls",0,2)

    def signUp_validation(self,testType):
        BaseFunctions(self.driver).jsonExistCheck("SignUpLocator") # Json repo existing or not check
        #
        # if driver.find_element_by_xpath("(//iframe[@id='apoptin'])").is_displayed():
        #     driver.switch_to_frame(driver.find_element_by_xpath("(//iframe[@id='apoptin'])"))
        #     driver.find_element_by_xpath("(//button[@id='ap-cookiesConfirm__accept'])").click()
        #     time.sleep(5)

        # self.driver.save_screenshot("/home/qbuser/Music/PythonScreenshots/screenshot.png")
        #
        # data_uri = base64.b64encode(open('/home/qbuser/Music/PythonScreenshots/screenshot.png', 'rb').read()).decode('utf-8')
        # img_tag = '<img src="data:image/png;base64,{0}">'.format(data_uri)
        # print(img_tag)

        Report(self.driver).testCaseStatus("Bowser Launched")
        if len(BaseFunctions(self.driver).webElements(SignUpLocator.iFrame))!=0:
            if BaseFunctions(self.driver).webElement(SignUpLocator.iFrame,"SignUpLocator.iFrame").is_displayed():
                self.driver.switch_to_frame(BaseFunctions(self.driver).webElement(SignUpLocator.iFrame,"SignUpLocator.iFrame"))
                BaseFunctions(self.driver).webElement(SignUpLocator.iFrame_Accept_BTN,"SignUpLocator.iFrame_Accept_BTN").click()

        if (testType=="mob"):
            BaseFunctions(self.driver).webElement(SignUpLocator.hmbrgr_menu).click()
            time.sleep(2)
            BaseFunctions(self.driver).webElement(SignUpLocator.freeTrail_Mob).click()
        else :
            BaseFunctions(self.driver).webElement(SignUpLocator.free_Trial_LNK_Dsktp,"SignUpLocator.free_Trial_LNK_Dsktp").click()



        # BaseFunctions(self.driver).webElement(SignUpLocator.free_Trial_LNK).click()
        #self.driver.find_element_by_xpath(SignUpLocator.free_Trial_LNK).click()
        Report(self.driver).testCaseStatus("Clicked on free trail link")

        BaseFunctions(self.driver).webElement(SignUpLocator.firstName_TXT_BX,"SignUpLocator.firstName_TXT_BX").send_keys(self.testData['firstName'])
        BaseFunctions(self.driver).webElement(SignUpLocator.lastName_TXT_BX,"SignUpLocator.lastName_TXT_BX").send_keys(self.testData['lastName'])
        BaseFunctions(self.driver).webElement(SignUpLocator.emailID_TXT_BX,"SignUpLocator.emailID_TXT_BX").send_keys(self.testData['email_Id'])
        BaseFunctions(self.driver).webElement(SignUpLocator.password_TXT_BOX,"SignUpLocator.password_TXT_BOX").send_keys(self.testData['password'])
        Report(self.driver).testCaseStatus("Entered User Details")
        if len(BaseFunctions(self.driver).webElements(SignUpLocator.iFrame))!= 0:
            if BaseFunctions(self.driver).webElement(SignUpLocator.iFrame, "SignUpLocator.iFrame").is_displayed():
                self.driver.switch_to_frame(BaseFunctions(self.driver).webElement(SignUpLocator.iFrame, "SignUpLocator.iFrame"))
                BaseFunctions(self.driver).webElement(SignUpLocator.iFrame_Accept_BTN, "SignUpLocator.iFrame_Accept_BTN").click()
        BaseFunctions(self.driver).webElement(SignUpLocator.tAndc_Check_Box,"SignUpLocator.tAndc_Check_Box").click()
        BaseFunctions(self.driver).webElement(SignUpLocator.startFree_BTN,"SignUpLocator.startFree_BTN").click()
        Report(self.driver).testCaseStatus("Accept Tearms and conditions and clicked on start free BTN")
        BaseFunctions(self.driver).webElement(SignUpLocator.companyTXT_Box,"SignUpLocator.companyTXT_Box").send_keys(self.testData['companyName'])
        BaseFunctions(self.driver).webElement(SignUpLocator.nextBTN,"SignUpLocator.nextBTN").click()
        Report(self.driver).testCaseStatus("User Entered Company Name")
        BaseFunctions(self.driver).webElement(SignUpLocator.companyWebsiteTXTBox,"SignUpLocator.companyWebsiteTXTBox").send_keys(self.testData['companyWebsite'])
        BaseFunctions(self.driver).webElement(SignUpLocator.linkedInUsername,"SignUpLocator.linkedInUsername").send_keys(self.testData['linkedInUserName'])
        BaseFunctions(self.driver).webElement(SignUpLocator.intentToUse,"SignUpLocator.intentToUse").send_keys(self.testData['intentToUse'])
        Report(self.driver).testCaseStatus("Entered Company Details , before clicked on submit")
        if len(BaseFunctions(self.driver).webElements(SignUpLocator.iFrame))!= 0:
            if BaseFunctions(self.driver).webElement(SignUpLocator.iFrame, "SignUpLocator.iFrame").is_displayed():
                self.driver.switch_to_frame(BaseFunctions(self.driver).webElement(SignUpLocator.iFrame, "SignUpLocator.iFrame"))
                BaseFunctions(self.driver).webElement(SignUpLocator.iFrame_Accept_BTN, "SignUpLocator.iFrame_Accept_BTN").click()
        BaseFunctions(self.driver).webElement(SignUpLocator.submit,"SignUpLocator.submit").click()
        Report(self.driver).testCaseStatus("clicked on submit - Navigated to next page &Success Msg is displayed")
        BaseFunctions(self.driver).webElement(SignUpLocator.goHomeBTN,"SignUpLocator.goHomeBTN").click()
        Report(self.driver).testCaseStatus("Clicked in Hoem BTN and user get navigated into Home page")


        print('\n'+" SignUp Flow Completed")

