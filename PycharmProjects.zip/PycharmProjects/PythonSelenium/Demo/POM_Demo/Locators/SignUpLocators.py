
class SignUpLocator():
    hmbrgr_menu = "xpath:(// button[@class ='header-icon fill-light-storm header-mobile-btn-menu plain-button bg-transparent p1'])"
    freeTrail_Mob ="xpath:(// a[@class ='h5 medium turquoise'])"
    free_Trial_LNK_Dsktp = "xpath:(//span[text()='Free Trial'])"
    firstName_TXT_BX = "xpath:(//input[@name='firstname'])"
    lastName_TXT_BX = "xpath:(//input[@name='lastname'])"
    emailID_TXT_BX = "name:email"
    password_TXT_BOX = "name:password"

    iFrame = "xpath:(//iframe[@id='apoptin'])"
    iFrame_Accept_BTN = "xpath:(//button[@id='ap-cookiesConfirm__accept'])"

    tAndc_Check_Box = "xpath:(//input[@id='termsandconditions'])"
    startFree_BTN = "xpath:(//span[@class='ap-button-text'])"

    companyTXT_Box = "xpath:(//input[@id='company'])"
    nextBTN = "xpath:(//span[@class='ap-button-text'])"

    companyWebsiteTXTBox = "xpath:(//input[@name='companywebsite'])"
    linkedInUsername = "xpath:(//input[@name='linkedinprofile'])"
    intentToUse = "xpath:(// input[@ name='intendeduse'])"
    submit = "xpath:(// button[@class ='ap-button ap-button--large ap-button--shadow bg-red block center w-100 mt3'])"

    goHomeBTN = "xpath:(//a[@class='link-hover-white ap-button ap-button--large ap-button--shadow ap-button--red'])"
    sucessMsg = "xpath:(//h3[@ class ='regular dark-storm mt2'])"
