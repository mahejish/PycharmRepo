import json
import os
import io
data = {}

class BaseFunctions:
    def __init__(self,driver):

        self.driver=driver

    def webElements(self, str):
        locator = str.split(':')[0]
        locatorAddrss = str.split(':')[1]
        if locator == "xpath":
            return self.driver.find_elements_by_xpath(locatorAddrss)
        elif locator == "name":
            return self.driver.find_elements_by_name(locatorAddrss)
        elif locator == "id":
            return self.driver.find_elements_by_id(locatorAddrss)
        elif locator == "class":
            return self.driver.find_elements_by_class_name(locatorAddrss)

    def webElement(self,str,loc):
        locator=str.split(':')[0]
        locatorAddrss=str.split(':')[1]
        if locator=="xpath":
            ele=self.driver.find_element_by_xpath(locatorAddrss)
            with open('/home/qbuser/Documents/'+loc.split(".")[0]+'.json','r+') as f:
                self.values = json.load(f)
            if loc.split(".")[1] in self.values.keys():
                pass
            else:
                self.json_Dict(loc,ele)
            return ele
        elif locator=="name":
            ele = self.driver.find_element_by_name(locatorAddrss)
            with open('/home/qbuser/Documents/'+loc.split(".")[0]+'.json','r+') as f:
                self.values = json.load(f)
            if loc.split(".")[1] in self.values.keys():
                pass
            else:
                self.json_Dict(loc, ele)
            return ele
        elif locator=="id":
            ele = self.driver.find_element_by_id(locatorAddrss)
            with open('/home/qbuser/Documents/'+loc.split(".")[0]+'.json','r+') as f:
                self.values = json.load(f)
            if loc.split(".")[1] in self.values.keys():
                pass
            else:
                self.json_Dict(loc, ele)
            return ele
        elif locator=="class":
            ele = self.driver.find_element_by_class_name(locatorAddrss)
            with open('/home/qbuser/Documents/' + loc.split(".")[0] + '.json', 'r+') as f:
                self.values = json.load(f)
            if loc.split(".")[1] in self.values.keys():
                pass
            else:
                self.json_Dict(loc, ele)
            return ele


    def json_Dict(self,locator,web_element):

        Dict = {}
        Dict["id"] = web_element.get_attribute("id")
        Dict["class"] = web_element.get_attribute("class")
        Dict["name"] = web_element.get_attribute("name")
        Dict["Text"] = web_element.get_attribute("text")
        Dict["LinkText"] = web_element.get_attribute("LinkText")
        Dict["Css_Selector"] = web_element.get_attribute("CssSelector")
        Dict["Xpath_relative"] = web_element.get_attribute("text")
        Dict["Unique_property"] = web_element.get_attribute("Unique_property")
        print(web_element.get_attribute('outerHTML'))


        data[locator.split(".")[1]] = []
        data[locator.split(".")[1]]={
            "Text": Dict["Text"],
            "Id": Dict["id"],
            "Class": Dict["class"],
            "Xpath_relative": Dict["Xpath_relative"],
            "Css_Selector": "value",
            "Name": Dict["name"],
            "LinkText": Dict["LinkText"],
            "Unique_property": Dict["Unique_property"]
        }
        with open('/home/qbuser/Documents/'+locator.split(".")[0]+'.json', 'w') as outfile:
            json.dump(data, outfile)
        # json_decoded['ADDED_KEY'] = 'ADDED_VALUE'

    def jsonExistCheck(self,fileNmae):
        if os.path.isfile('/home/qbuser/Documents/'+fileNmae+'.json') and os.access('/home/qbuser/Documents/'+fileNmae+'.json', os.R_OK):
            # checks if file exists
            pass
        else:
            with io.open(os.path.join('/home/qbuser/Documents', fileNmae+'.json'), 'w') as db_file:
                db_file.write(json.dumps({}))